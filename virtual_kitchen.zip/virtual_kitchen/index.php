<?php
session_start();
if (!isset($_SESSION['uid'])) {
    header("Location: login.php");
    exit();
}
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "virtual_kitchen";
$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
$username = $_SESSION['username'];
$sql = "SELECT * FROM recipes";
$result = $conn->query($sql);
$searchQuery = isset($_GET['search']) ? $_GET['search'] : ''; //for searching recipes
if ($searchQuery) {
    $sql = "SELECT * FROM recipes WHERE name LIKE ? OR ingredients LIKE ?";
    $stmt = $conn->prepare($sql);
    $searchTerm = "%" . $searchQuery . "%";
    $stmt->bind_param("ss", $searchTerm, $searchTerm);
    $stmt->execute();
    $result = $stmt->get_result();
} else {
    $sql = "SELECT * FROM recipes";
    $result = $conn->query($sql);
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Welcome to Virtual Kitchen by Yousaf</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background: #5D0C1D;
            color: #CCB38D;
            margin: 0;
            padding: 0;
        }
        header {
            background: #5D0C1D;
            color: #CCB38D;
            padding: 20px;
            text-align: center; //for the header center cuz it looks better
        }
        .container {
            padding: 20px;
        }
        .card {
            background: white;
            border-radius: 10px;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
            padding: 20px;
            margin: 20px auto;
            width: 80%;
            max-width: 700px;
            color: #5D0C1D;
        }
        .card img {
            max-width: 100%;
            border-radius: 10px;
        }
        .card p {
            font-size: 16px;
            color: #DAF449;
        }
        footer {
            background-color: #5D0C1D;
            color: #CCB38D;
            padding: 20px;
            text-align: center;
        }
        .logout-btn {
            background: #DAF449;
            color: #5D0C1D;
            border: none;
            padding: 10px 20px;
            cursor: pointer;
            text-decoration: none;
            border-radius: 5px;
            font-size: 16px;
        }
        .nav-buttons {
            display: flex;
            gap: 10px; 
            justify-content: center; 
            margin-top: 10px;
        }
        .nav-btn {
            background: #DAF449;
            color: #5D0C1D;
            text-decoration: none;
            padding: 10px 20px;
            border-radius: 5px;
            font-size: 16px;
            font-weight: bold;
            border: none;
            cursor: pointer;
            transition: background 0.3s ease;
        }
        .nav-btn:hover {
            background: #c9d63b;
        }
    </style>
</head>
<body>
<header>
    <h1>Welcome, <?php echo htmlspecialchars($username); ?>!</h1>
    <form method="get" action="index.php" style="display: flex; justify-content: center; gap: 10px; margin-top: 10px;">
        <input type="text" name="search" placeholder="Search recipes or ingredients..." required style="padding: 10px; width: 300px; font-size: 16px; border-radius: 5px;">
        <input type="submit" value="Search" style="padding: 10px 20px; background-color: #DAF449; color: #5D0C1D; border-radius: 5px; font-size: 16px;">
    </form>
    <div class="nav-links">
        <h2>Navigation</h2>
        <ul>
            <li><a href="index.php">Home</a></li>
            <li><a href="edit_recipe.php">Edit Recipe</a></li>
            <li><a href="add_recipe.php">Add Recipe</a></li>
            <li><a href="logout.php">Logout</a></li>
        </ul>
    </div>
</header>
<header>
    <h1>Welcome, <?php echo htmlspecialchars($username); ?>!</h1>
    <a href="logout.php" class="logout-btn">Logout</a>
</header>
<div class="container">
    <h2>Recipes</h2>
    <?php
    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            echo "<div class='card'>";
            echo "<h2>" . htmlspecialchars($row['name']) . "</h2>";
            echo "<img src='" . htmlspecialchars($row['image']) . "' alt='" . htmlspecialchars($row['name']) . "'>";
            echo "<p><strong>Description:</strong> " . htmlspecialchars($row['description']) . "</p>";
            echo "<p><strong>Type:</strong> " . htmlspecialchars($row['type']) . "</p>";
            echo "<p><strong>Cooking Time:</strong> " . $row['Cookingtime'] . " minutes</p>";
            echo "<p><strong>Ingredients:</strong><br>" . nl2br(htmlspecialchars($row['ingredients'])) . "</p>";
            echo "<p><strong>Instructions:</strong><br>" . nl2br(htmlspecialchars($row['instructions'])) . "</p>";
            echo "</div>";
        }
    } else {
        echo "<p>No recipes found.</p>";
    }

    $conn->close();
    ?>
</div>
<footer>
    <p>&copy; Made by: Mohammed Yousaf Bashir | Email: <a href="mailto:240364665@aston.ac.uk">240364665@aston.ac.uk</a> | Student Number: 240364665</p>
</footer>
</body>
</html>
