<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "virtual_kitchen";

$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) { //chcecking and creating the actual connection
  die("Connection failed: " . $conn->connect_error);
}

$sql = "SELECT * FROM recipes";
$result = $conn->query($sql);
echo "<html>
<head>
  <title>Recipe List</title>
  <style>
    body { 
        font-family: Arial, sans-serif; 
        background: #5D0C1D; 
        margin: 0; 
        padding: 0; 
        color: #CCB38D;
    }
    h1 {
        text-align: center;
        color: #CCB38D;
        padding: 20px 0;
    }
    .card {
        background: white;
        border-radius: 10px;
        box-shadow: 0 4px 10px rgba(0,0,0,0.1);
        padding: 20px;
        margin: 20px auto;
        width: 80%;
        max-width: 700px;
        color: #5D0C1D;
        transition: transform 0.3s ease-in-out;
    }
    .card:hover {
        transform: scale(1.05); /* Slightly enlarge the card on hover */
    }
    img {
        max-width: 100%;
        border-radius: 10px;
        margin-bottom: 15px;
        box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
    }
    h2 { 
        color: #DAF449; 
        text-align: center; 
        font-size: 24px;
    }
    .card h2 {
        color: #DAF449;
        text-align: center; //for the header center cuz it looks better
    }
    p { 
        color: #DAF449; 
        line-height: 1.6; 
    }
    strong { 
        color: #CCB38D; 
    }
    .card p {
        font-size: 16px;
    }
    .card p strong {
        color: #CCB38D;
    }
    footer {
        background-color: #5D0C1D;
        color: #CCB38D;
        padding: 20px;
        text-align: center;
    }
  </style>
</head>
<body>
<h1>Recipes</h1>";

if ($result->num_rows > 0) {
  while($row = $result->fetch_assoc()) {
    echo "<div class='card'>";
    echo "<h2>" . htmlspecialchars($row['name']) . "</h2>";
    echo "<img src='" . htmlspecialchars($row['image']) . "' alt='" . htmlspecialchars($row['name']) . "'>";
    echo "<p><strong>Description:</strong> " . htmlspecialchars($row['description']) . "</p>";
    echo "<p><strong>Type:</strong> " . htmlspecialchars($row['type']) . "</p>";
    echo "<p><strong>Cooking Time:</strong> " . $row['Cookingtime'] . " minutes</p>";
    echo "<p><strong>Ingredients:</strong><br>" . nl2br(htmlspecialchars($row['ingredients'])) . "</p>";
    echo "<p><strong>Instructions:</strong><br>" . nl2br(htmlspecialchars($row['instructions'])) . "</p>";
    echo "</div>";
  }
} else {
  echo "<p>No recipes found.</p>";
}
echo "</body></html>";
$conn->close(); //essentially ends the connection
?>
