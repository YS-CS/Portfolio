<?php
session_start();
session_destroy();
header("Location: login.php"); //takes back to login page after login out
exit();
?>