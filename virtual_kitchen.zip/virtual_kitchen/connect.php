<?php
include 'connect.php';
$sql = "SELECT * FROM recipes";
$result = $conn->query($sql);
if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        echo "<div class='recipe'>";
        echo "<img src='images/" . $row['image'] . "' alt='" . $row['title'] . "'>";
        echo "<h2>" . $row['title'] . "</h2>";
        echo "<p>" . $row['description'] . "</p>";
        echo "</div>";
    }
} else {
    echo "No recipes found.";
}
$conn->close();
?>