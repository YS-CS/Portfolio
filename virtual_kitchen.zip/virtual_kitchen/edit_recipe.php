<?php
session_start();
if (!isset($_SESSION['uid'])) {
    die("Ensre ur logged in");
}
if (!isset($_GET['rid'])) {
    die("rid is not in url");
}
$rid = isset($_GET['rid']) ? intval($_GET['rid']) : 0;
var_dump($rid); //debug (checking for rid vairble)
if ($rid == 0) {
    die("No recipe ID provided.");
}
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "virtual_kitchen";
$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
$uid = $_SESSION['uid'];
$errors = []; //checking if ur logged in
$stmt = $conn->prepare("SELECT * FROM recipes WHERE rid = 1 AND uid = 1");
$stmt->execute();
$result = $stmt->get_result();
$recipe = $result->fetch_assoc(); //getter for recipe
if (!$recipe) {
    die("Recipe wasnt found so cannot edit it");
}
var_dump($rid, $_SESSION['uid']);
var_dump($rid, $uid, $recipe); //debug (checking for rid, uid and recipe)
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = trim($_POST['name']);
    $type = $_POST['type'];
    $description = trim($_POST['description']);
    $ingredients = trim($_POST['ingredients']);
    $instructions = trim($_POST['instructions']);
    $cookingtime = intval($_POST['cookingtime']);
    if (empty($name) || empty($description) || empty($ingredients) || empty($instructions) || $cookingtime <= 0) {
        $errors[] = "Make sure nothing is empty"; //checkin if any is empty
    }
    if (empty($errors)) {
        $stmt = $conn->prepare("UPDATE recipes SET name = ?, description = ?, type = ?, cookingtime = ?, ingredients = ?, instructions = ? WHERE rid = ? AND uid = ?");
        $stmt->bind_param("sssissii", $name, $description, $type, $cookingtime, $ingredients, $instructions, $rid, $uid);

        if ($stmt->execute()) {
            header("Location: index.php");
            exit();
        } else {
            $errors[] = "Couldnt change or add to recipe";
        }
    }
}
$recipeNames = [];
$sql = "SELECT rid, name FROM recipes";
$result = mysqli_query($conn, $sql);
if ($result && mysqli_num_rows($result) > 0) {
    while ($row = mysqli_fetch_assoc($result)) { //checking for the recipe names
        $recipeNames[] = $row;
    }
}
?>
<!DOCTYPE html>
<html>
<head><title>Edit Recipe</title></head>
<head>
    <meta charset="UTF-8">
    <title>Add Recipe</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background: #5D0C1D;
            color: #CCB38D;
            padding: 20px;
        }
        form {
            background: white;
            padding: 20px;
            border-radius: 10px;
            max-width: 500px;
            margin: 0 auto;
        }
        input, textarea, select {
            width: 100%;
            padding: 10px;
            margin-top: 10px;
            border-radius: 5px;
            border: 1px solid #ddd;
        }
        button {
            background: #5D0C1D;
            color: white;
            border: none;
            padding: 10px;
            border-radius: 5px;
            cursor: pointer;
            width: 100%;
            margin-top: 15px;
        }
    </style>
</head>
<body>
<div class="nav-links">
    <h2>Navigation</h2>
    <ul>
        <li><a href="index.php">Home</a></li>
        <li><a href="add_recipe.php">Add Recipe</a></li>
        <li><a href="logout.php">Logout</a></li>
    </ul>
</div>
<h2>Edit Your Recipe</h2>
<?php if (!empty($errors)): ?>
    <div class="error">
        <?php foreach ($errors as $error): ?>
            <p><?= htmlspecialchars($error) ?></p>
        <?php endforeach; ?>
    </div>
<?php endif; ?>
<form method="post">
    <input type="hidden" name="rid" value="<?= htmlspecialchars($recipe['rid']) ?>">
    <label>Recipe Name: 
        <input type="text" name="name" value="<?= htmlspecialchars($recipe['name']) ?>" required>
    </label><br>
    <!-- for existing recipe to chose to edit (keeping text box if u wanna cahnge name)-->
    <label>Select Existing Recipe:
        <select name="recipe_id" id="recipe_id">
            <option value="">-- Choose a recipe --</option>
            <?php foreach ($recipeNames as $recipeOption): ?>
                <option value="<?= htmlspecialchars($recipeOption['rid']) ?>"
                    <?= isset($recipe['rid']) && $recipe['rid'] == $recipeOption['rid'] ? 'selected' : '' ?>>
                    <?= htmlspecialchars($recipeOption['name']) ?>
                </option>
            <?php endforeach; ?>
        </select>
    </label><br>
    <label>Type:
        <select name="type" required>
            <?php
            $types = ["French", "Italian", "Chinese", "Indian", "Mexican", "Others"];
            foreach ($types as $type) {
                $selected = $type == $recipe['type'] ? "selected" : "";
                echo "<option value='$type' $selected>$type</option>";
            }
            ?>
        </select>
    </label><br>
    <label>Description: <textarea name="description" required><?= htmlspecialchars($recipe['description']) ?></textarea></label><br>
    <label>Ingredients: <textarea name="ingredients" required><?= htmlspecialchars($recipe['ingredients']) ?></textarea></label><br>
    <label>Instructions: <textarea name="instructions" required><?= htmlspecialchars($recipe['instructions']) ?></textarea></label><br>
    <label>Cooking Time (mins): <input type="number" name="cookingtime" value="<?php echo htmlspecialchars($recipe['Cookingtime']); ?>" required></label><br>
    <input type="submit" value="Update Recipe">
</form>
</body>
</html>