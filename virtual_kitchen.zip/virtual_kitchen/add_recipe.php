<?php
session_start();
if (!isset($_SESSION['uid'])) {
    header("Location: login.php");
    exit();
}
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "virtual_kitchen";
$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = mysqli_real_escape_string($conn, $_POST['name']);
    $type = mysqli_real_escape_string($conn, $_POST['type']);
    $description = mysqli_real_escape_string($conn, $_POST['description']);
    $ingredients = mysqli_real_escape_string($conn, $_POST['ingredients']);
    $instructions = mysqli_real_escape_string($conn, $_POST['instructions']);
    $cookingtime = (int)$_POST['cookingtime'];
    $uid = $_SESSION['uid'];
    $imageName = '';
    if (isset($_FILES['image']) && $_FILES['image']['error'] == 0) {
        $targetDir = "uploads/";
        if (!is_dir($targetDir)) {
            mkdir($targetDir);
        }
        $imageName = basename($_FILES["image"]["name"]);
        $targetFile = $targetDir . $imageName;
        move_uploaded_file($_FILES["image"]["tmp_name"], $targetFile);
    }
    $sql = "INSERT INTO recipes (uid, name, type, description, ingredients, instructions, cookingtime, image)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)"; //inserts the recipes varibales
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("isssssis", $uid, $name, $type, $description, $ingredients, $instructions, $cookingtime, $imageName);
    if ($stmt->execute()) {
        echo "Recipe is added now</a>";
    } else {
        echo "Error: " . $stmt->error;
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Add Recipe</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background: #5D0C1D;
            color: #CCB38D;
            padding: 20px;
        }
        form {
            background: white;
            padding: 20px;
            border-radius: 10px;
            max-width: 500px;
            margin: 0 auto;
        }
        input, textarea, select {
            width: 100%;
            padding: 10px;
            margin-top: 10px;
            border-radius: 5px;
            border: 1px solid #ddd;
        }
        button {
            background: #5D0C1D;
            color: white;
            border: none;
            padding: 10px;
            border-radius: 5px;
            cursor: pointer;
            width: 100%;
            margin-top: 15px;
        }
    </style>
</head>
<body>
<div class="nav-links">
    <h2>Navigation</h2>
    <ul>
        <li><a href="index.php">Home</a></li>
        <li><a href="add_recipe.php">Add Recipe</a></li>
        <li><a href="logout.php">Logout</a></li>
    </ul>
</div>
    <h1>Add your own recipes!</h1>
    <form action="add_recipe.php" method="POST" enctype="multipart/form-data">
        <input type="text" name="name" placeholder="Recipe Name" required>
        <input type="text" name="type" placeholder="Type (e.g., Dessert, Main)">
        <textarea name="description" placeholder="Short Description" required></textarea>
        <textarea name="ingredients" placeholder="Ingredients (comma-separated)" required></textarea>
        <textarea name="instructions" placeholder="Instructions" required></textarea>
        <input type="number" name="cookingtime" placeholder="Cooking Time (minutes)" required>
        <input type="file" name="image">
        <button type="submit">Add Recipe</button>
    </form>
</body>
</html>